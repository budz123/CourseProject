﻿using Budz.Lopushok.Domain.Entities;
using Budz.Lopushok.infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budz.Lopushok.Presentation.ViewModels
{
    public class MainViewModel : ViewModelBase
    {

        public List<Product> Products { get; set; } 

        public MainViewModel()
        {
            using(ApplicationDbContext contex = new ApplicationDbContext())
            {
                Products= contex.Products
                    .Include(p => p.ProductType)
                    .Include(m=>m.ProductMaterials)
                    .ThenInclude(pm => pm.Material)
                    .ToList();
            }
        }

    }

    internal class Item
    {
        public string Title { get; set; } = null!;
        public string Type { get; set; } = null!;
        public string Materials { get; set; } = null!;
        public decimal Cost { get; set; } 
        public string ArtcileNumber { get; set; } = null!;
    }

}
